# Olla App scaffold

Run streamlit app:
- set SUPABASE_URL and SUPABASE_KEY env vars if using Supabase
- pip install streamlit
- streamlit run streamlit-app/olla_dashboard_app.py

Run webhook:
- pip install -r webhook-service/requirements.txt
- uvicorn webhook-service.main:app --reload --port 8000