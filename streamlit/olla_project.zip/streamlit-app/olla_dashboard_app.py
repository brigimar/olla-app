"""Streamlit app (Admin + Modo Abuela) - simplified for scaffold"""
import streamlit as st
from datetime import datetime, timedelta
import pandas as pd
import os

try:
    from supabase import create_client as create_supabase_client
    SUPABASE_AVAILABLE = True
except Exception:
    SUPABASE_AVAILABLE = False

try:
    import plotly.express as px
    PLOTLY_AVAILABLE = True
except Exception:
    PLOTLY_AVAILABLE = False

SUPABASE_URL = os.getenv("SUPABASE_URL","")
SUPABASE_KEY = os.getenv("SUPABASE_KEY","")
AUTO_REFRESH_SECONDS = 120

def get_supabase():
    if SUPABASE_AVAILABLE and SUPABASE_URL and SUPABASE_KEY:
        return create_supabase_client(SUPABASE_URL, SUPABASE_KEY)
    return None

def mock_data():
    orders = [
        {"id":1,"producer_id":"p1","amount":1200,"commission":120,"status":"delivered","created_at":datetime.now().isoformat()},
        {"id":2,"producer_id":"p2","amount":800,"commission":80,"status":"preparing","created_at":datetime.now().isoformat()},
    ]
    users = [{"id":"u1","name":"María","email":"maria@example.com","active":True,"role":"admin"}]
    bypass = [{"id":"b1","order_id":99,"producer_id":"p2","reason":"suspicious","score":0.9,"created_at":datetime.now().isoformat()}]
    return orders, users, bypass

def fetch_data(supabase):
    try:
        if supabase is None:
            raise RuntimeError("no supabase")
        orders = supabase.table("orders").select("*").execute().data
        users = supabase.table("users").select("*").execute().data
        bypass = supabase.table("bypass_alerts_log").select("*").order("created_at",{"ascending":False}).limit(200).execute().data
        return orders, users, bypass
    except Exception:
        return mock_data()

st.set_page_config(page_title="Olla Dashboards", layout="centered")

with st.sidebar:
    view = st.radio("Dashboard", ["Admin","Modo Abuela"])
    offline = st.checkbox("Modo offline", value=False)

supabase = None if offline else get_supabase()
orders, users, bypass_logs = fetch_data(supabase)

if view == "Admin":
    st.title("Admin Dashboard")
    st.metric("Ventas (hoy)", value=len([o for o in orders if o.get("status")!="cancelled"]))
    st.metric("Ingresos", value=f"${sum([o.get('amount',0) for o in orders]):.2f}")
    st.markdown("### Logs de bypass")
    st.dataframe(pd.DataFrame(bypass_logs))
else:
    st.title("MODO ABUELA")
    st.markdown("<div style='font-size:44px;font-weight:700'>Modo Abuela</div>", unsafe_allow_html=True)
    st.markdown(f"<div style='font-size:32px'>Ventas hoy: {len([o for o in orders if o.get('status')!='cancelled'])}</div>", unsafe_allow_html=True)
    menu = st.text_area("Menú de la mañana","Tortilla + Ensalada + Agua", height=120)
    if st.button("Guardar local"):
        st.session_state['last_menu'] = menu
        st.success("Menú guardado localmente")