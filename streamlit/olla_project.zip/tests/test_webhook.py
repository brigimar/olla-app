from fastapi.testclient import TestClient
from webhook_service.main import app

client = TestClient(app)

def test_receive_bypass():
    payload = {"order_id": 999, "producer_id": "pX", "reason": "test", "score": 0.9}
    res = client.post("/webhook/bypass", json=payload)
    assert res.status_code == 200
    assert res.json()["status"] == "received"