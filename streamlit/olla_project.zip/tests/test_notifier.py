import asyncio
from notifier.notifier import notify_bypass_if_needed

def test_notify_logs(monkeypatch):
    called = {"email":False}
    def fake_send_email(subject, body, to_list):
        called["email"] = True
    monkeypatch.setattr("notifier.notifier.send_email", fake_send_email)
    asyncio.run(notify_bypass_if_needed({"order_id":123,"producer_id":"p1","reason":"test","score":0.9}))
    assert called["email"] is True